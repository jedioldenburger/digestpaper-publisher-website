DigestPaper — Nebula (clean) ULTRA Pack
==================================
Includes: SVG sources, square icons (16..1024), iOS icons, maskable PWA (192/512),
wordmarks (300x60, 600x120, 900x220, 1200x240), monochrome black/white,
favicon.ico (16/32/48), social images (1200x630, 1500x500), and an SVG sprite.

Sprite usage:
  <svg width="600" height="120" role="img" aria-label="DigestPaper">
    <use href="#nebula-clean-wordmark-600x120"></use>
  </svg>

PWA:
  Link manifest.json and use the provided maskable icons.
